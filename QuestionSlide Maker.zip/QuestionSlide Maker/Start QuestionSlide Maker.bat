@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3 is required. Install it from python.org, then double-click this file again.
    pause
    exit /b 1
  )
  set "PY=python"
) else (
  set "PY=py -3"
)
%PY% -m pip install -r requirements.txt
if errorlevel 1 (
  echo Could not install the app requirements. Check your internet connection and try again.
  pause
  exit /b 1
)
%PY% main.py
if errorlevel 1 pause
