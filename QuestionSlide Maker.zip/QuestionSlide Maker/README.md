# QuestionSlide Maker

A desktop tool for creating one-question-per-slide PDFs from digital or scanned maths papers. The original page content is rendered directly into each slide, so equations and diagrams are not reconstructed.

## Run

1. Install Python 3.10 or newer.
2. Double-click `Start QuestionSlide Maker.bat` (or install `requirements.txt` and run `python main.py`).
3. For scanned PDFs and images, install the Tesseract OCR program once. Windows download information: https://tesseract-ocr.github.io/tessdoc/Downloads.html

## Workflow

1. Open a PDF or a PNG/JPG/TIFF/BMP/WEBP scan.
2. Select **Suggest starts**. Digital text is read from the PDF; scanned pages use OCR. In worked-example books, clear `EXAMPLE N` headings take priority over equation numbers and subparts, and the question continues across page breaks until the next example heading. OCR only proposes start locations; it never replaces or rewrites the math.
3. Inspect the start markers. Click the page to add a start and select a list item then choose **Remove marker** to delete a bad suggestion. Blue markers are included by the current filter; gray markers are outside it; amber markers were added manually.
4. To work on only part of a document, enter the inclusive **From** and **To** page numbers, choose **All pages**, **Odd pages**, or **Even pages**, then click **Apply filter** (or press Enter in a page field). The preview jumps to the first matching page. Previous/next navigation follows only pages in the applied filter. The filter selects question starts by their page number. A selected question remains complete if it continues past the selected range; the next detected start still ends it correctly.
5. Export slides. The original content between each start and the next start is rendered as an image, followed by solving room.

The source is never changed. Large PDFs open with only the current page rendered for preview; start detection runs in the background and can be cancelled. Preview uses **Fit page** by default, with zoom controls for detail. Images open as one-page documents. For multi-page image sets, combine them into a PDF first. Review long questions and multi-column pages carefully; very long content is scaled to fit a slide.
