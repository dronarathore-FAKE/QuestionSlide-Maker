"""QuestionSlide Maker: review PDF question boundaries and export image-based slides."""

from __future__ import annotations

import io
import os
import queue
import re
import shutil
import threading
import tkinter as tk
from dataclasses import dataclass, field
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import pymupdf as fitz
from PIL import Image, ImageChops, ImageDraw, ImageTk

try:
    import pytesseract
    from pytesseract import Output as TesseractOutput
except ImportError:
    pytesseract = None
    TesseractOutput = None


@dataclass(order=True)
class Boundary:
    page: int  # zero-based
    y: float   # PDF points from page top
    label: str = ""
    question_y: float | None = field(default=None, compare=False)
    marker_page: int | None = field(default=None, compare=False)
    context_prefix: list[tuple[int, float, float]] | None = field(default=None, compare=False)
    manual: bool = field(default=False, compare=False)


class QuestionSlideApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        root.title("QuestionSlide Maker")
        root.geometry("1440x940")
        root.minsize(1120, 760)
        self.colors = {
            "canvas": "#111827",
            "ink": "#172033",
            "muted": "#64748B",
            "line": "#E6EAF0",
            "paper": "#FFFFFF",
            "surface": "#FFFFFF",
            "window": "#F3F5F9",
            "navy": "#101A2B",
            "blue": "#4169E1",
            "blue_dark": "#3154C7",
        }
        self.doc: fitz.Document | None = None
        self.source: Path | None = None
        self.boundaries: list[Boundary] = []
        self.page_index = 0
        self.zoom = 1.0
        self.zoom_factor = 1.0
        self.page_image_left = 16
        self.page_image_top = 16
        self._render_after_id: str | None = None
        self._analysis_thread: threading.Thread | None = None
        self._analysis_queue: queue.Queue = queue.Queue()
        self._analysis_cancel: threading.Event | None = None
        self._analysis_after_id: str | None = None
        self._analysis_generation = 0
        self._ocr_available = False
        self.photo: ImageTk.PhotoImage | None = None
        self.page_from = tk.StringVar(value="1")
        self.page_to = tk.StringVar(value="1")
        self.page_parity = tk.StringVar(value="All pages")
        self._active_page_filter: tuple[int, int, str] | None = None
        self.start_summary = tk.StringVar(value="0 questions")
        self.filter_summary = tk.StringVar(value="Open a document to select pages")
        self.zoom_summary = tk.StringVar(value="Fit")
        self.source_summary = tk.StringVar(value="Open a PDF or image to begin")
        self._configure_style()
        self._build_ui()

    def _configure_style(self) -> None:
        c = self.colors
        self.root.configure(background=c["window"])
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background=c["window"])
        style.configure("Header.TFrame", background=c["navy"])
        style.configure("Surface.TFrame", background=c["surface"])
        style.configure("ViewerToolbar.TFrame", background="#1A2638")
        style.configure("TLabel", background=c["window"], foreground=c["ink"], font=("Segoe UI", 10))
        style.configure("Card.TLabel", background=c["surface"], foreground=c["ink"], font=("Segoe UI", 10))
        style.configure("Muted.Card.TLabel", background=c["surface"], foreground=c["muted"], font=("Segoe UI", 9))
        style.configure("HeaderTitle.TLabel", background=c["navy"], foreground="#FFFFFF", font=("Segoe UI Semibold", 20))
        style.configure("HeaderSub.TLabel", background=c["navy"], foreground="#AAB7C9", font=("Segoe UI", 9))
        style.configure("HeaderMeta.TLabel", background=c["navy"], foreground="#D6DEEA", font=("Segoe UI", 9))
        style.configure("Section.TLabel", background=c["surface"], foreground=c["ink"], font=("Segoe UI Semibold", 12))
        style.configure("Kicker.TLabel", background=c["surface"], foreground="#64748B", font=("Segoe UI Semibold", 8))
        style.configure("Count.TLabel", background=c["surface"], foreground=c["blue"], font=("Segoe UI Semibold", 9))
        style.configure("Viewer.TLabel", background="#1A2638", foreground="#E7EDF6", font=("Segoe UI", 9))
        style.configure("ViewerStrong.TLabel", background="#1A2638", foreground="#FFFFFF", font=("Segoe UI Semibold", 9))
        style.configure("Primary.TButton", background=c["blue"], foreground="#FFFFFF", padding=(14, 9), font=("Segoe UI Semibold", 9), borderwidth=0)
        style.map("Primary.TButton", background=[("active", c["blue_dark"]), ("disabled", "#9AA9C3")], foreground=[("disabled", "#FFFFFF")])
        style.configure("Secondary.TButton", background="#E8EEFF", foreground="#2947A3", padding=(11, 8), font=("Segoe UI Semibold", 9), borderwidth=0)
        style.map("Secondary.TButton", background=[("active", "#D7E1FF"), ("disabled", "#F1F3F8")], foreground=[("disabled", "#9AA3B2")])
        style.configure("Quiet.TButton", background="#FFFFFF", foreground="#344054", padding=(10, 8), font=("Segoe UI", 9), borderwidth=1)
        style.map("Quiet.TButton", background=[("active", "#F4F6FA"), ("disabled", "#F3F4F6")], foreground=[("disabled", "#9AA3B2")])
        style.configure("Viewer.TButton", background="#26354B", foreground="#F4F7FB", padding=(7, 5), font=("Segoe UI Semibold", 9), borderwidth=0)
        style.map("Viewer.TButton", background=[("active", "#354863"), ("disabled", "#1A2638")], foreground=[("disabled", "#758399")])
        style.configure("TEntry", padding=(8, 7), fieldbackground="#FFFFFF", foreground=c["ink"], bordercolor=c["line"])
        style.configure("TCombobox", padding=(7, 6), fieldbackground="#FFFFFF", foreground=c["ink"])
        style.configure("TScrollbar", background="#CBD2DE", troughcolor="#E8ECF2", bordercolor="#E8ECF2", arrowsize=12)
        style.configure("Dark.Vertical.TScrollbar", background="#475467", troughcolor="#1A2638", bordercolor="#1A2638", arrowsize=12)
        style.configure("TPanedwindow", background=c["window"])

    def _build_ui(self) -> None:
        header = ttk.Frame(self.root, style="Header.TFrame", padding=(22, 13))
        header.pack(fill="x")
        brand = ttk.Frame(header, style="Header.TFrame")
        brand.pack(side="left", fill="x", expand=True)
        brand_mark = tk.Label(brand, text="Q", background=self.colors["blue"], foreground="#FFFFFF", font=("Segoe UI Semibold", 15), width=2, height=1, padx=2, pady=2)
        brand_mark.pack(side="left", padx=(0, 12))
        brand_copy = ttk.Frame(brand, style="Header.TFrame")
        brand_copy.pack(side="left", fill="x", expand=True)
        ttk.Label(brand_copy, text="QuestionSlide", style="HeaderTitle.TLabel").pack(anchor="w")
        ttk.Label(brand_copy, textvariable=self.source_summary, style="HeaderSub.TLabel").pack(anchor="w", pady=(1, 0))
        actions = ttk.Frame(header, style="Header.TFrame")
        actions.pack(side="right")
        ttk.Button(actions, text="Open PDF", command=self.open_pdf, style="Quiet.TButton").pack(side="left", padx=(0, 8))
        self.detect_button = ttk.Button(actions, text="Detect starts", command=self.suggest_boundaries, style="Secondary.TButton", state="disabled")
        self.detect_button.pack(side="left", padx=(0, 8))
        self.cancel_button = ttk.Button(actions, text="Cancel", command=self.cancel_detection, style="Quiet.TButton", state="disabled")
        self.cancel_button.pack(side="left", padx=(0, 8))
        self.remove_button = ttk.Button(actions, text="Remove marker", command=self.remove_boundary, style="Quiet.TButton", state="disabled")
        self.remove_button.pack(side="left", padx=(0, 8))
        self.export_button = ttk.Button(actions, text="Export slides", command=self.export_pdf, style="Primary.TButton", state="disabled")
        self.export_button.pack(side="left")

        selection = ttk.Frame(self.root, style="Surface.TFrame", padding=(18, 12))
        selection.pack(fill="x", padx=18, pady=(12, 8))
        selection_heading = ttk.Frame(selection, style="Surface.TFrame")
        selection_heading.pack(fill="x")
        ttk.Label(selection_heading, text="Export range", style="Section.TLabel").pack(side="left")
        ttk.Label(selection_heading, text="Questions are selected by their start page", style="Muted.Card.TLabel").pack(side="left", padx=(10, 0), pady=(2, 0))
        ttk.Label(selection_heading, textvariable=self.filter_summary, style="Count.TLabel").pack(side="right")
        controls = ttk.Frame(selection, style="Surface.TFrame")
        controls.pack(fill="x", pady=(9, 0))
        ttk.Label(controls, text="FROM PAGE", style="Kicker.TLabel").pack(side="left", padx=(0, 6))
        self.page_from_entry = ttk.Entry(controls, textvariable=self.page_from, width=7, justify="center", state="disabled")
        self.page_from_entry.pack(side="left", padx=(0, 16))
        ttk.Label(controls, text="TO PAGE", style="Kicker.TLabel").pack(side="left", padx=(0, 6))
        self.page_to_entry = ttk.Entry(controls, textvariable=self.page_to, width=7, justify="center", state="disabled")
        self.page_to_entry.pack(side="left", padx=(0, 16))
        ttk.Label(controls, text="INCLUDE", style="Kicker.TLabel").pack(side="left", padx=(0, 6))
        self.parity_combo = ttk.Combobox(controls, textvariable=self.page_parity, values=("All pages", "Odd pages", "Even pages"), state="readonly", width=13)
        self.parity_combo.configure(state="disabled")
        self.parity_combo.pack(side="left", padx=(0, 12))
        self.apply_button = ttk.Button(controls, text="Apply filter", command=self.apply_page_selection, style="Secondary.TButton", state="disabled")
        self.apply_button.pack(side="left")
        self.page_from_entry.bind("<Return>", lambda _event: self.apply_page_selection())
        self.page_to_entry.bind("<Return>", lambda _event: self.apply_page_selection())
        ttk.Label(selection, text="The preview jumps to the first included page. A question that continues onto later pages stays complete.", style="Muted.Card.TLabel").pack(anchor="w", pady=(7, 0))

        status_bar = ttk.Frame(self.root, style="Surface.TFrame", padding=(16, 7))
        status_bar.pack(fill="x", padx=18, pady=(0, 9))
        self.status = tk.StringVar(value="Open a PDF or image to begin. Review suggested starts before exporting.")
        ttk.Label(status_bar, textvariable=self.status, style="Muted.Card.TLabel").pack(anchor="w")

        body = ttk.Panedwindow(self.root, orient="horizontal")
        body.pack(fill="both", expand=True, padx=18, pady=(0, 16))
        side = ttk.Frame(body, width=308, style="Surface.TFrame", padding=14)
        body.add(side, weight=0)
        side_header = ttk.Frame(side, style="Surface.TFrame")
        side_header.pack(fill="x")
        ttk.Label(side_header, text="Question starts", style="Section.TLabel").pack(side="left")
        ttk.Label(side_header, textvariable=self.start_summary, style="Count.TLabel").pack(side="right")
        ttk.Label(side, text="Review detected questions. Select one to jump to its page; click the page to add a marker.", style="Muted.Card.TLabel", wraplength=272, justify="left").pack(anchor="w", pady=(5, 10))
        list_frame = ttk.Frame(side, style="Surface.TFrame")
        list_frame.pack(fill="both", expand=True)
        self.boundary_list = tk.Listbox(list_frame, height=20, activestyle="none", relief="flat", borderwidth=0,
                                        background="#F7F9FC", foreground="#243146", selectbackground="#DCE7FF",
                                        selectforeground="#2449A4", font=("Segoe UI", 9), highlightthickness=1,
                                        highlightbackground="#E6EAF0", highlightcolor="#91AAEF", selectborderwidth=0)
        list_scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.boundary_list.yview)
        self.boundary_list.configure(yscrollcommand=list_scroll.set)
        self.boundary_list.pack(side="left", fill="both", expand=True)
        list_scroll.pack(side="right", fill="y")
        self.boundary_list.bind("<<ListboxSelect>>", self.jump_to_boundary)
        ttk.Label(side, text="Blue included   ·   Gray excluded   ·   Amber manual", style="Muted.Card.TLabel", wraplength=272).pack(anchor="w", pady=(9, 0))

        viewport = ttk.Frame(body, style="TFrame")
        body.add(viewport, weight=1)
        viewer_toolbar = ttk.Frame(viewport, style="ViewerToolbar.TFrame", padding=(12, 7))
        viewer_toolbar.grid(row=0, column=0, columnspan=2, sticky="ew")
        ttk.Button(viewer_toolbar, text="‹", width=3, command=lambda: self.change_page(-1), style="Viewer.TButton").pack(side="left")
        self.page_label = tk.StringVar(value="No document")
        ttk.Label(viewer_toolbar, textvariable=self.page_label, style="ViewerStrong.TLabel").pack(side="left", padx=(10, 12))
        ttk.Button(viewer_toolbar, text="›", width=3, command=lambda: self.change_page(1), style="Viewer.TButton").pack(side="left")
        ttk.Frame(viewer_toolbar, style="ViewerToolbar.TFrame").pack(side="left", fill="x", expand=True)
        ttk.Button(viewer_toolbar, text="−", width=3, command=self.zoom_out, style="Viewer.TButton").pack(side="left", padx=(8, 4))
        ttk.Label(viewer_toolbar, textvariable=self.zoom_summary, style="Viewer.TLabel", width=6, anchor="center").pack(side="left")
        ttk.Button(viewer_toolbar, text="+", width=3, command=self.zoom_in, style="Viewer.TButton").pack(side="left", padx=4)
        ttk.Button(viewer_toolbar, text="Fit page", command=self.fit_page, style="Viewer.TButton").pack(side="left", padx=(4, 0))
        self.canvas = tk.Canvas(viewport, background=self.colors["canvas"], highlightthickness=0, borderwidth=0)
        scroll_y = ttk.Scrollbar(viewport, orient="vertical", command=self.canvas.yview, style="Dark.Vertical.TScrollbar")
        scroll_x = ttk.Scrollbar(viewport, orient="horizontal", command=self.canvas.xview, style="Dark.Vertical.TScrollbar")
        self.canvas.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.canvas.grid(row=1, column=0, sticky="nsew")
        scroll_y.grid(row=1, column=1, sticky="ns")
        scroll_x.grid(row=2, column=0, sticky="ew")
        viewport.rowconfigure(1, weight=1)
        viewport.columnconfigure(0, weight=1)
        self.canvas.bind("<Button-1>", self.add_boundary_at_click)
        self.canvas.bind("<Configure>", self._schedule_preview_refresh)
        self.canvas.bind("<MouseWheel>", self._scroll_preview)
        self.canvas.bind("<Shift-MouseWheel>", self._scroll_preview_horizontal)
        self.root.bind("<Left>", self._on_navigation_key)
        self.root.bind("<Right>", self._on_navigation_key)
        self._refresh(reset_view=True)

    def open_pdf(self) -> None:
        name = filedialog.askopenfilename(title="Open question paper or scan", filetypes=[("PDF and image files", "*.pdf *.png *.jpg *.jpeg *.tif *.tiff *.bmp *.webp"), ("All files", "*.*")])
        if not name:
            return
        new_doc: fitz.Document | None = None
        try:
            path = Path(name)
            suffix = path.suffix.lower()
            if suffix == ".pdf":
                new_doc = fitz.open(str(path))
            else:
                new_doc = fitz.open()
                with Image.open(path) as source_image:
                    for frame in range(getattr(source_image, "n_frames", 1)):
                        source_image.seek(frame)
                        image = source_image.convert("RGB")
                        buffer = io.BytesIO()
                        image.save(buffer, format="PNG")
                        scale = 72 / 150
                        pdf_page = new_doc.new_page(width=image.width * scale, height=image.height * scale)
                        pdf_page.insert_image(pdf_page.rect, stream=buffer.getvalue())
                        image.close()
            if not new_doc or len(new_doc) < 1:
                raise ValueError("The selected file does not contain any pages.")
            self._cancel_analysis()
            old_doc = self.doc
            self.doc = new_doc
            self.source = path
            new_doc = None
            if old_doc:
                old_doc.close()
            self.page_index = 0
            self.zoom_factor = 1.0
            self.boundaries = []
            self.page_from.set("1")
            self.page_to.set(str(len(self.doc)))
            self.page_parity.set("All pages")
            self._active_page_filter = (1, len(self.doc), "All pages")
            self.source_summary.set(f"{self.source.name}  ·  {len(self.doc):,} pages")
            for widget in (self.page_from_entry, self.page_to_entry, self.apply_button, self.parity_combo):
                widget.configure(state="readonly" if widget is self.parity_combo else "normal")
            self.detect_button.configure(state="normal")
            self.remove_button.configure(state="disabled")
            self.export_button.configure(state="disabled")
            self.status.set(f"Ready · {len(self.doc):,} pages loaded. Select a range, detect starts, then review before exporting.")
            self._refresh(reset_view=True)
        except Exception as exc:
            if new_doc:
                new_doc.close()
            messagebox.showerror("Could not open PDF", str(exc))

    def _read_page_filter(self) -> tuple[int, int, str] | None:
        if not self.doc:
            return None
        try:
            first = int(self.page_from.get().strip())
            last = int(self.page_to.get().strip())
        except ValueError:
            messagebox.showerror("Check page range", "Enter whole page numbers in both From and To.")
            return None
        if first < 1 or last < first or last > len(self.doc):
            messagebox.showerror("Check page range", f"Choose a range from 1 to {len(self.doc)}, with From no greater than To.")
            return None
        parity = self.page_parity.get()
        if parity not in {"All pages", "Odd pages", "Even pages"}:
            parity = "All pages"
        if self._first_included_page(first, last, parity) is None:
            messagebox.showerror("No pages match", f"There are no {parity.lower()} in pages {first}–{last}.")
            return None
        return first, last, parity

    @staticmethod
    def _first_included_page(first: int, last: int, parity: str) -> int | None:
        page = first
        if parity == "Odd pages" and page % 2 == 0:
            page += 1
        elif parity == "Even pages" and page % 2 == 1:
            page += 1
        return page if page <= last else None

    def _page_is_selected(self, page_index: int) -> bool:
        if not self._active_page_filter:
            return True
        first, last, parity = self._active_page_filter
        page_number = page_index + 1
        if not first <= page_number <= last:
            return False
        if parity == "Odd pages":
            return page_number % 2 == 1
        if parity == "Even pages":
            return page_number % 2 == 0
        return True

    def _selected_boundaries(self) -> list[Boundary]:
        return [boundary for boundary in sorted(self.boundaries) if self._page_is_selected(boundary.page)]

    def apply_page_selection(self) -> None:
        if not self.doc:
            messagebox.showinfo("Open a file first", "Open a PDF or image before choosing pages.")
            return
        page_filter = self._read_page_filter()
        if page_filter is None:
            return
        self._cancel_analysis()
        self._active_page_filter = page_filter
        self.page_index = self._first_included_page(*page_filter) - 1
        self.zoom_factor = 1.0
        selected_count = len(self._selected_boundaries())
        first, last, parity = page_filter
        self.status.set(f"Filter applied · pages {first}–{last}, {parity.lower()} · {selected_count} question start(s) included.")
        self._refresh(reset_view=True)

    def _render_page(self) -> Image.Image:
        assert self.doc is not None
        page = self.doc.load_page(self.page_index)
        pix = page.get_pixmap(matrix=fitz.Matrix(self.zoom, self.zoom), alpha=False, annots=True)
        return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)

    def _fit_zoom(self) -> float:
        assert self.doc is not None
        page = self.doc.load_page(self.page_index)
        self.canvas.update_idletasks()
        width = max(360, self.canvas.winfo_width() - 64)
        height = max(320, self.canvas.winfo_height() - 56)
        fit = min(width / page.rect.width, height / page.rect.height)
        pixel_cap = min(2600 / page.rect.width, 3000 / page.rect.height)
        return max(0.005, min(fit, pixel_cap))

    def _refresh(self, reset_view: bool = False) -> None:
        old_x = self.canvas.xview()[0]
        old_y = self.canvas.yview()[0]
        old_selection = self.boundary_list.curselection()
        self.boundaries.sort()
        self.boundary_list.delete(0, tk.END)
        included_count = 0
        for i, b in enumerate(self.boundaries, 1):
            label = b.label or f"Start {i}"
            included = self._page_is_selected(b.page)
            included_count += int(included)
            suffix = "" if included else "  ·  outside filter"
            self.boundary_list.insert(tk.END, f"{label}  ·  p.{b.page + 1}{suffix}")
            color = "#A16207" if b.manual else ("#1D4ED8" if included else "#94A3B8")
            self.boundary_list.itemconfigure(i - 1, foreground=color)
        self.start_summary.set(f"{included_count} included  ·  {len(self.boundaries)} total")
        if old_selection and old_selection[0] < len(self.boundaries):
            self.boundary_list.selection_set(old_selection[0])
        self.remove_button.configure(state="normal" if self.boundary_list.curselection() else "disabled")
        self.export_button.configure(state="normal" if included_count else "disabled")
        if self.doc:
            page_state = "included" if self._page_is_selected(self.page_index) else "outside filter"
            self.page_label.set(f"Page {self.page_index + 1:,} / {len(self.doc):,}  ·  {page_state}")
            self.zoom = self._fit_zoom() * self.zoom_factor
            page = self.doc.load_page(self.page_index)
            self.zoom = min(self.zoom, 2600 / page.rect.width, 3000 / page.rect.height)
            fit_zoom = self._fit_zoom()
            percent = max(1, round(self.zoom / max(0.01, fit_zoom) * 100))
            self.zoom_summary.set("Fit" if abs(self.zoom_factor - 1.0) < 0.01 else f"{percent}%")
            self.canvas.delete("all")
            viewport_w = max(360, self.canvas.winfo_width())
            viewport_h = max(320, self.canvas.winfo_height())
            try:
                rendered = self._render_page()
                self.photo = ImageTk.PhotoImage(rendered)
                rendered.close()
            except Exception as exc:
                self.photo = None
                self.page_image_left = self.page_image_top = 0
                self.canvas.configure(scrollregion=(0, 0, viewport_w, viewport_h))
                self.canvas.create_text(viewport_w / 2, viewport_h / 2,
                                        text="This page could not be previewed.\nTry another page or reopen the PDF.",
                                        fill="#FCA5A5", font=("Segoe UI", 13), justify="center")
                self.status.set(f"Preview failed on page {self.page_index + 1}: {exc}")
                return
            self.page_image_left = max(22, (viewport_w - self.photo.width()) // 2)
            self.page_image_top = max(20, (viewport_h - self.photo.height()) // 2)
            right = self.page_image_left + self.photo.width()
            bottom = self.page_image_top + self.photo.height()
            self.canvas.create_rectangle(self.page_image_left + 7, self.page_image_top + 7, right + 7, bottom + 7, fill="#070B12", outline="", tags="page-shadow")
            self.canvas.create_image(self.page_image_left, self.page_image_top, image=self.photo, anchor="nw", tags="page")
            self.canvas.create_rectangle(self.page_image_left, self.page_image_top, right, bottom, outline="#D9DEE8", width=1, tags="page-border")
            self.canvas.configure(scrollregion=(0, 0, max(viewport_w, right + 20), max(viewport_h, bottom + 20)))
            for b in self.boundaries:
                if b.page == self.page_index:
                    yy = self.page_image_top + b.y * self.zoom
                    included = self._page_is_selected(b.page)
                    color = "#D97706" if b.manual else ("#2563EB" if included else "#94A3B8")
                    options = {"fill": color, "width": 3}
                    if not included:
                        options["dash"] = (6, 4)
                    self.canvas.create_line(self.page_image_left, yy, right, yy, **options)
                    self.canvas.create_text(self.page_image_left + 8, yy - 7, text=b.label or "QUESTION START", fill=color, anchor="sw", font=("Segoe UI", 10, "bold"))
            if reset_view:
                self.canvas.xview_moveto(0)
                self.canvas.yview_moveto(0)
            else:
                self.canvas.xview_moveto(old_x)
                self.canvas.yview_moveto(old_y)
            if self._active_page_filter:
                first, last, parity = self._active_page_filter
                self.filter_summary.set(f"{included_count} question start(s) · pages {first}–{last} · {parity}")
        else:
            self.page_label.set("No document")
            self.zoom_summary.set("Fit")
            self.canvas.delete("all")
            self.canvas.update_idletasks()
            width = max(1, self.canvas.winfo_width())
            height = max(1, self.canvas.winfo_height())
            self.canvas.configure(scrollregion=(0, 0, width, height))
            self.canvas.create_text(width / 2, height / 2, text="Open a PDF or image to preview it here", fill="#AAB7C9", font=("Segoe UI", 13))

    def change_page(self, delta: int) -> None:
        if not self.doc:
            return
        pages = [index for index in range(len(self.doc)) if self._page_is_selected(index)]
        if not pages:
            return
        try:
            position = pages.index(self.page_index)
        except ValueError:
            position = next((i for i, index in enumerate(pages) if index >= self.page_index), len(pages) - 1)
        self.page_index = pages[max(0, min(len(pages) - 1, position + delta))]
        self._refresh(reset_view=True)

    def _on_navigation_key(self, event: tk.Event) -> str | None:
        if event.widget in {self.page_from_entry, self.page_to_entry}:
            return None
        self.change_page(-1 if event.keysym == "Left" else 1)
        return "break"

    def _schedule_preview_refresh(self, _event: tk.Event | None = None) -> None:
        if not self.doc:
            return
        if self._render_after_id:
            self.root.after_cancel(self._render_after_id)
        self._render_after_id = self.root.after(160, self._refresh_after_resize)

    def _refresh_after_resize(self) -> None:
        self._render_after_id = None
        if self.doc:
            self._refresh(reset_view=False)

    def zoom_in(self) -> None:
        if not self.doc:
            return
        self.zoom_factor = min(4.0, self.zoom_factor * 1.25)
        self._refresh(reset_view=True)

    def zoom_out(self) -> None:
        if not self.doc:
            return
        self.zoom_factor = max(0.5, self.zoom_factor / 1.25)
        self._refresh(reset_view=True)

    def fit_page(self) -> None:
        if not self.doc:
            return
        self.zoom_factor = 1.0
        self._refresh(reset_view=True)

    def _scroll_preview(self, event: tk.Event) -> str:
        steps = max(1, abs(int(event.delta / 120)))
        self.canvas.yview_scroll(-steps if event.delta > 0 else steps, "units")
        return "break"

    def _scroll_preview_horizontal(self, event: tk.Event) -> str:
        steps = max(1, abs(int(event.delta / 120)))
        self.canvas.xview_scroll(-steps if event.delta > 0 else steps, "units")
        return "break"

    def add_boundary_at_click(self, event: tk.Event) -> None:
        if not self.doc:
            return
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        if x < self.page_image_left or x > self.page_image_left + self.photo.width():
            return
        if y < self.page_image_top:
            return
        y = (y - self.page_image_top) / self.zoom
        page_height = self.doc[self.page_index].rect.height
        if y >= page_height:
            return
        if any(b.page == self.page_index and abs(b.y - y) < 8 for b in self.boundaries):
            return
        label = f"Q{len(self.boundaries) + 1}"
        self.boundaries.append(Boundary(self.page_index, y, label, manual=True))
        self.status.set(f"Added {label} start on page {self.page_index + 1}. Drag-free workflow: click at the top edge of each question.")
        self._refresh()

    def suggest_boundaries(self) -> None:
        if not self.doc or not self.source:
            return
        if self._analysis_thread and self._analysis_thread.is_alive():
            self.status.set("Detection is already running. Wait for it to finish or cancel it first.")
            return
        page_filter = self._read_page_filter()
        if page_filter is None:
            return
        self._active_page_filter = page_filter
        self.page_index = self._first_included_page(*page_filter) - 1
        self._refresh(reset_view=True)
        ocr_available = False
        if pytesseract is not None:
            tesseract_path = self._find_tesseract()
            if tesseract_path:
                pytesseract.pytesseract.tesseract_cmd = str(tesseract_path)
            try:
                pytesseract.get_tesseract_version()
                ocr_available = True
            except Exception:
                ocr_available = False
        self._analysis_generation += 1
        generation = self._analysis_generation
        cancel_event = threading.Event()
        self._analysis_cancel = cancel_event
        source_path = self.source
        self.detect_button.configure(state="disabled")
        self.cancel_button.configure(state="normal")
        self.status.set(f"Starting detection for pages {page_filter[0]}–{page_filter[1]}…")

        def report_progress(page_number: int, total: int) -> None:
            self._analysis_queue.put((generation, "progress", (page_number, total)))

        def worker() -> None:
            analysis_doc: fitz.Document | None = None
            try:
                analysis_doc = self._open_analysis_document(source_path)
                result = self._detect_boundaries_sync(analysis_doc, page_filter, cancel_event, ocr_available, report_progress)
                self._analysis_queue.put((generation, "done", result))
            except Exception as exc:
                self._analysis_queue.put((generation, "error", str(exc)))
            finally:
                if analysis_doc:
                    analysis_doc.close()

        self._analysis_thread = threading.Thread(target=worker, name="QuestionSlide detector", daemon=True)
        self._analysis_thread.start()
        self._analysis_after_id = self.root.after(120, self._poll_analysis_queue)

    def _open_analysis_document(self, path: Path) -> fitz.Document:
        if path.suffix.lower() == ".pdf":
            return fitz.open(str(path))
        document = fitz.open()
        try:
            with Image.open(path) as source_image:
                for frame in range(getattr(source_image, "n_frames", 1)):
                    source_image.seek(frame)
                    image = source_image.convert("RGB")
                    buffer = io.BytesIO()
                    image.save(buffer, format="PNG")
                    scale = 72 / 150
                    page = document.new_page(width=image.width * scale, height=image.height * scale)
                    page.insert_image(page.rect, stream=buffer.getvalue())
                    image.close()
            return document
        except Exception:
            document.close()
            raise

    def _poll_analysis_queue(self) -> None:
        self._analysis_after_id = None
        latest_progress: tuple[int, int] | None = None
        finished = False
        while True:
            try:
                generation, kind, payload = self._analysis_queue.get_nowait()
            except queue.Empty:
                break
            if generation != self._analysis_generation:
                continue
            if kind == "progress":
                latest_progress = payload
            elif kind == "done":
                found, missing_ocr, pages_scanned, cancelled = payload
                finished = True
                self._analysis_thread = None
                self._analysis_cancel = None
                self.detect_button.configure(state="normal" if self.doc else "disabled")
                self.cancel_button.configure(state="disabled")
                if cancelled:
                    self.status.set("Detection cancelled. Existing markers are still available.")
                else:
                    self.boundaries = [boundary for boundary in self.boundaries if boundary.manual]
                    self.boundaries.extend(found)
                    self.boundaries.sort()
                    for index, boundary in enumerate(self.boundaries, 1):
                        if not boundary.label or boundary.label.startswith("Start"):
                            boundary.label = f"Q{index}"
                    self._refresh()
                    included_count = len(self._selected_boundaries())
                    first, last, parity = self._active_page_filter or (1, len(self.doc), "All pages")
                    if missing_ocr:
                        messagebox.showwarning("OCR unavailable", "Some pages in this range are scans, but Tesseract could not read them. Install Tesseract to suggest starts on scanned pages. You can still add markers manually.")
                    if found:
                        self.status.set(f"Found {len(found)} starts across {pages_scanned:,} analyzed pages · {included_count} in pages {first}–{last} ({parity.lower()}). Review before exporting.")
                    elif missing_ocr:
                        self.status.set("No starts found on scanned pages. Install Tesseract or add starts manually.")
                    else:
                        self.status.set("No starts found in the selected range. Try another range or add starts manually.")
            elif kind == "error":
                finished = True
                self._analysis_thread = None
                self._analysis_cancel = None
                self.detect_button.configure(state="normal" if self.doc else "disabled")
                self.cancel_button.configure(state="disabled")
                messagebox.showerror("Detection failed", payload)
                self.status.set("Detection failed. The document preview is still available.")
        if latest_progress and not finished:
            page_number, total = latest_progress
            self.status.set(f"Analyzing page {page_number:,} of {total:,}… You can keep using the preview.")
        thread_running = self._analysis_thread is not None and self._analysis_thread.is_alive()
        if self._analysis_thread and not thread_running:
            self._analysis_thread = None
            self._analysis_cancel = None
            self.detect_button.configure(state="normal" if self.doc else "disabled")
            self.cancel_button.configure(state="disabled")
        if not finished and thread_running:
            self._analysis_after_id = self.root.after(120, self._poll_analysis_queue)

    def cancel_detection(self) -> None:
        if self._analysis_cancel and not self._analysis_cancel.is_set():
            self._analysis_cancel.set()
            self.cancel_button.configure(state="disabled")
            self.status.set("Stopping after the current page…")

    def _cancel_analysis(self) -> None:
        if self._analysis_cancel:
            self._analysis_cancel.set()
        self._analysis_generation += 1
        thread_running = self._analysis_thread is not None and self._analysis_thread.is_alive()
        self.detect_button.configure(state="disabled" if thread_running else ("normal" if self.doc else "disabled"))
        self.cancel_button.configure(state="normal" if thread_running else "disabled")
        if thread_running and not self._analysis_after_id:
            self._analysis_after_id = self.root.after(120, self._poll_analysis_queue)

    def _detect_boundaries_sync(self, document: fitz.Document, page_filter: tuple[int, int, str], cancel_event: threading.Event,
                                ocr_available: bool, progress: object) -> tuple[list[Boundary], bool, int, bool]:
        found: list[Boundary] = []
        example_starts: list[Boundary] = []
        lines_by_page: dict[int, list[tuple[float, str]]] = {}
        first_page, last_page, _parity = page_filter
        last_selected_page = last_page - 1
        scan_start = max(0, first_page - 2)
        missing_ocr = False
        pages_scanned = 0
        # Read coordinate-bearing text lines in the question-number column. A narrow
        # left-side band avoids mistaking fractions/options elsewhere in the row for starts.
        for pno in range(scan_start, len(document)):
            if cancel_event.is_set():
                return found, missing_ocr, pages_scanned, True
            page = document.load_page(pno)
            width = page.rect.width
            page_dict = page.get_text("dict")
            lines_by_page[pno] = []
            for block in page_dict.get("blocks", []):
                for line in block.get("lines", []):
                    spans = line.get("spans", [])
                    text = " ".join(s.get("text", "") for s in spans).strip()
                    if not text:
                        continue
                    x0 = min(s["bbox"][0] for s in spans)
                    y0 = min(s["bbox"][1] for s in spans)
                    compact = " ".join(text.split())
                    lines_by_page[pno].append((y0, compact))
                    # Worked-example books label full problems explicitly. Prefer
                    # those headings over equation numbers and (i)/(ii) subparts.
                    example_match = re.match(r"^EXAMPLE\s+(\d{1,3})\b", compact, re.I)
                    if x0 < width * 0.4 and y0 < page.rect.height * 0.96 and example_match:
                        number = example_match.group(1)
                        if not any(b.page == pno and b.label == f"Example {number}" for b in example_starts):
                            marker_y = max(0, y0 - 2)
                            example_starts.append(Boundary(pno, marker_y, f"Example {number}", question_y=marker_y, marker_page=pno))
                    # In many question papers the number and prompt share one line
                    # (e.g. "23. Solve ..." or "24. (A) ..."). Match the leading
                    # label instead of requiring a number-only text line.
                    match = re.match(r"^\s*(?:Q(?:uestion)?\s*)?(\d{1,2})(?:[.)])?\s*(?:\([A-D]\))?(?=\s|$)", compact, re.I)
                    if x0 < width * 0.16 and y0 < page.rect.height * 0.93 and match:
                        number = match.group(1)
                        if not any(b.page == pno and b.label == f"Q{number}" for b in found):
                            marker_y = max(0, y0 - 2)
                            found.append(Boundary(pno, marker_y, f"Q{number}", question_y=marker_y, marker_page=pno))
            has_text = bool(lines_by_page[pno])
            if not has_text or self._page_has_full_page_image(page):
                if ocr_available:
                    try:
                        ocr_found = self._suggest_with_ocr(document, [pno], ocr_available)
                    except Exception:
                        missing_ocr = True
                        ocr_found = []
                    if ocr_found:
                        found = [boundary for boundary in found if boundary.page != pno] + ocr_found
                        example_starts = [boundary for boundary in example_starts if boundary.page != pno]
                        example_starts.extend(boundary for boundary in ocr_found if boundary.label.startswith("Example "))
                elif not has_text:
                    missing_ocr = True
            pages_scanned += 1
            progress(pno + 1, len(document))
            page_starts = example_starts if example_starts else found
            if pno > last_selected_page and any(boundary.page == pno for boundary in page_starts):
                break
        # If explicit example headings exist, they are the true problem starts;
        # suppress equation numbers and exercise subparts elsewhere on the page.
        if example_starts:
            found = example_starts

        if not found:
            return [], missing_ocr, pages_scanned, cancel_event.is_set()
        found.sort()
        # Attach section titles and instructions to the first numbered question that follows.
        for pno, page_lines in lines_by_page.items():
            page = document.load_page(pno)
            page_questions = [b for b in found if b.page == pno]
            page_questions.sort(key=lambda b: b.question_y if b.question_y is not None else b.y)
            for y, text in page_lines:
                section = re.fullmatch(r"\(?\s*SECTION\s*(?:[–—-]\s*)?([A-E])\s*\)?", text, re.I)
                if not section:
                    continue
                block_top = y
                companions = [line_y for line_y, line_text in page_lines
                              if 0 <= line_y - y <= 55 and re.match(r"^(?:This section comprises|Section\s+[A-E]\s+consists)\b", line_text, re.I)]
                if companions:
                    block_top = min(block_top, min(companions))
                next_question = next((b for b in page_questions
                                      if (b.question_y if b.question_y is not None else b.y) >= y), None)
                if next_question and (next_question.question_y if next_question.question_y is not None else next_question.y) - y <= 180:
                    next_question.y = min(next_question.y, block_top)

            # Shared direction blocks are repeated as image context for each named question.
            for y, text in page_lines:
                directions = re.search(r"Directions:.*?questions?\s+(?:number\s+)?(\d+)\s+and\s+(\d+)", text, re.I)
                if not directions:
                    continue
                first_num, last_num = map(int, directions.groups())
                title_y = [line_y for line_y, line_text in page_lines
                           if line_y <= y and y - line_y <= 40 and re.search(r"Assertion.?Reason Based Questions", line_text, re.I)]
                context_top = min(title_y + [y])
                option_ys = [line_y for line_y, line_text in page_lines
                             if y <= line_y <= y + 220 and re.match(r"^\([A-D]\)", line_text, re.I)]
                context_bottom = max(option_ys, default=y) + 18
                context_spans = [(pno, context_top, min(page.rect.height, context_bottom))]
                first_boundary = next((b for b in found if b.label == f"Q{first_num}" and
                                       (b.page > pno or (b.page == pno and (b.question_y or b.y) >= y))), None)
                if first_boundary:
                    first_boundary.marker_page = first_boundary.page
                    first_boundary.question_y = first_boundary.question_y if first_boundary.question_y is not None else first_boundary.y
                    first_boundary.page = pno
                    first_boundary.y = context_top
                    for number in range(first_num + 1, last_num + 1):
                        following = next((b for b in found if b.label == f"Q{number}"), None)
                        if following:
                            following.context_prefix = context_spans
        found.sort()
        return found, missing_ocr, pages_scanned, cancel_event.is_set()

    def _suggest_with_ocr(self, document: fitz.Document, page_numbers: list[int], ocr_available: bool) -> list[Boundary]:
        if pytesseract is None or not ocr_available:
            return []

        result: list[Boundary] = []
        example_result: list[Boundary] = []
        for pno in page_numbers:
            page = document[pno]
            render_scale = min(2.5, 3000 / max(page.rect.width, page.rect.height))
            pix = page.get_pixmap(matrix=fitz.Matrix(render_scale, render_scale), alpha=False)
            image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            try:
                data = pytesseract.image_to_data(image, config="--psm 3", output_type=TesseractOutput.DICT)
            finally:
                image.close()
            del pix
            groups: dict[tuple[int, int, int], list[int]] = {}
            for i, word in enumerate(data["text"]):
                if word.strip():
                    key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
                    groups.setdefault(key, []).append(i)
            candidates = []
            for indexes in groups.values():
                text = " ".join(data["text"][i].strip() for i in indexes).strip()
                example_match = re.match(r"^EXAMPLE\s+(\d{1,3})\b", text, re.I)
                confidences = [float(data["conf"][i]) for i in indexes
                               if str(data["conf"][i]).replace(".", "", 1).lstrip("-").isdigit()]
                if example_match and confidences and max(confidences) >= 35:
                    left = min(data["left"][i] for i in indexes)
                    top = min(data["top"][i] for i in indexes)
                    y = top / render_scale
                    if left / render_scale < page.rect.width * 0.4 and y < page.rect.height * 0.96:
                        number = example_match.group(1)
                        marker_y = max(0, y - 2)
                        if not any(b.page == pno and b.label == f"Example {number}" for b in example_result):
                            example_result.append(Boundary(pno, marker_y, f"Example {number}", question_y=marker_y, marker_page=pno))
                    continue
                match = re.match(r"^\s*(?:Q(?:uestion)?\s*)?(\d{1,2})\s*[.)]?(?:\s|$)", text, re.I)
                if not match:
                    continue
                if not confidences or max(confidences) < 50:
                    continue
                left = min(data["left"][i] for i in indexes)
                top = min(data["top"][i] for i in indexes)
                y = top / render_scale
                # Avoid common running page numbers in the bottom margin.
                if y > page.rect.height * .93:
                    continue
                candidates.append((left / render_scale, y, match.group(1)))
            if not candidates:
                continue
            # Order columns left-to-right, then top-to-bottom. This suits textbook
            # pages; the user can correct any unusual reading order in the review list.
            x_values = sorted(x for x, _y, _n in candidates)
            split_x = None
            if len(x_values) >= 4:
                gaps = [(x_values[i + 1] - x_values[i], (x_values[i + 1] + x_values[i]) / 2) for i in range(len(x_values) - 1)]
                gap, center = max(gaps)
                if gap > page.rect.width * .12 and page.rect.width * .18 < center < page.rect.width * .82:
                    split_x = center
            candidates.sort(key=lambda item: ((0 if split_x is None or item[0] < split_x else 1), item[1]))
            seen: set[tuple[str, int]] = set()
            for x, y, number in candidates:
                key = (number, round(y / 8))
                if key in seen:
                    continue
                seen.add(key)
                result.append(Boundary(pno, max(0, y - 2), f"Q{number}", question_y=max(0, y - 2), marker_page=pno))
        return example_result or result

    @staticmethod
    def _page_has_full_page_image(page: fitz.Page) -> bool:
        page_area = page.rect.width * page.rect.height
        if page_area <= 0:
            return False
        try:
            for image_info in page.get_images(full=True):
                for image_rect in page.get_image_rects(image_info[0]):
                    clipped = image_rect & page.rect
                    if clipped.width * clipped.height >= page_area * 0.8:
                        return True
        except Exception:
            return False
        return False

    @staticmethod
    def _find_tesseract() -> Path | None:
        """Find Tesseract on PATH or in common Windows installation folders."""
        configured = os.environ.get("TESSERACT_CMD", "").strip().strip('"')
        candidates = [Path(configured)] if configured else []
        path_exe = shutil.which("tesseract")
        if path_exe:
            candidates.append(Path(path_exe))
        candidates.extend([
            Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe"),
            Path(r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"),
        ])
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            candidates.append(Path(local_app_data) / "Programs" / "Tesseract-OCR" / "tesseract.exe")
        for candidate in candidates:
            if candidate.is_file():
                return candidate
        return None

    def remove_boundary(self) -> None:
        selected = self.boundary_list.curselection()
        if selected:
            del self.boundaries[selected[0]]
            self.boundary_list.selection_clear(0, tk.END)
            self._refresh()
            self.status.set("Marker removed.")

    def jump_to_boundary(self, _event: tk.Event) -> None:
        selected = self.boundary_list.curselection()
        if selected and self.boundaries:
            index = selected[0]
            boundary = self.boundaries[index]
            self.page_index = boundary.page
            self._refresh(reset_view=True)
            self.boundary_list.selection_set(index)
            self.remove_button.configure(state="normal")
            total_height = max(1, self.page_image_top + self.photo.height() + 20)
            target_y = max(0, self.page_image_top + boundary.y * self.zoom - 24)
            self.canvas.yview_moveto(min(1, target_y / total_height))

    def export_pdf(self) -> None:
        if not self.doc or not self.source:
            return
        page_filter = self._read_page_filter()
        if page_filter is None:
            return
        self._active_page_filter = page_filter
        self._refresh()
        if not self.boundaries:
            messagebox.showinfo("Add question starts", "Add at least one question start or use Suggest starts before exporting.")
            return
        selected_starts = self._selected_boundaries()
        if not selected_starts:
            messagebox.showinfo("No starts in selected pages", "No question starts are inside the selected page range and odd/even filter. Change the filter or add a start on an included page.")
            return
        dest = filedialog.asksaveasfilename(title="Save question slides", initialfile=f"{self.source.stem}_slides.pdf", defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
        if not dest:
            return
        try:
            self._write_slides(Path(dest), selected_starts)
            self.status.set(f"Exported {len(selected_starts)} question slides to {Path(dest).name}")
            messagebox.showinfo("Export complete", f"Saved {len(selected_starts)} slides:\n{dest}")
        except Exception as exc:
            messagebox.showerror("Export failed", str(exc))

    def _write_slides(self, destination: Path, selected_starts: list[Boundary]) -> None:
        assert self.doc is not None
        all_bounds = sorted(self.boundaries)
        selected_starts = sorted(selected_starts)
        # 4:3 slide with a large source area and room below for working.
        page_w, page_h = 1200, 900
        content_h = 740
        output = fitz.open()
        for start in selected_starts:
            start_index = next(i for i, boundary in enumerate(all_bounds) if boundary is start)
            end = all_bounds[start_index + 1] if start_index + 1 < len(all_bounds) else Boundary(len(self.doc) - 1, self.doc[-1].rect.height + 1, "")
            crops: list[tuple[int, fitz.Rect]] = []
            if start.context_prefix:
                for prefix_page, prefix_top, prefix_bottom in start.context_prefix:
                    page = self.doc[prefix_page]
                    prefix_clip = fitz.Rect(0, prefix_top, page.rect.width, min(prefix_bottom, page.rect.height))
                    if prefix_clip.height <= 0:
                        continue
                    trimmed = self._trim_clip_to_content(page, prefix_clip)
                    if trimmed.height > 0:
                        crops.append((prefix_page, trimmed))
            for pno in range(start.page, end.page + 1):
                page = self.doc[pno]
                top = start.y if pno == start.page else 0
                bottom = end.y if pno == end.page else page.rect.height
                if bottom <= top:
                    continue
                clip = fitz.Rect(0, top, page.rect.width, min(bottom, page.rect.height))
                if clip.height <= 0:
                    continue
                trimmed = self._trim_clip_to_content(page, clip)
                if trimmed.height > 0:
                    crops.append((pno, trimmed))
            if not crops:
                continue

            # Keep only lightweight PDF rectangles in memory. Render each cropped
            # panel at its final slide resolution so long questions cannot allocate
            # hundreds of full-page bitmaps at once.
            total_height = sum(clip.height for _pno, clip in crops)
            widest_panel = max(clip.width for _pno, clip in crops)
            scale = min((page_w - 64) / widest_panel, content_h / total_height)
            target_content_height = max(1, min(content_h, round(total_height * scale)))
            exact_panel_heights = [clip.height * scale for _pno, clip in crops]
            panel_heights = [int(height) for height in exact_panel_heights]
            remaining_pixels = target_content_height - sum(panel_heights)
            if remaining_pixels > 0:
                by_fraction = sorted(range(len(crops)),
                                     key=lambda i: exact_panel_heights[i] - panel_heights[i], reverse=True)
                for index in by_fraction[:remaining_pixels]:
                    panel_heights[index] += 1
            canvas = Image.new("RGB", (page_w, page_h), "white")
            y = 24
            for (pno, clip), panel_height in zip(crops, panel_heights):
                if panel_height <= 0:
                    continue
                page = self.doc[pno]
                panel_scale = panel_height / clip.height
                pix = page.get_pixmap(matrix=fitz.Matrix(panel_scale, panel_scale), clip=clip, alpha=False)
                panel = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
                target_width = max(1, min(page_w - 64, round(clip.width * panel_scale)))
                if panel.size != (target_width, panel_height):
                    resized = panel.resize((target_width, panel_height), Image.Resampling.LANCZOS)
                    panel.close()
                    panel = resized
                canvas.paste(panel, ((page_w - target_width) // 2, y))
                y += panel_height
                panel.close()
            # Separate the preserved original question and blank working area visually.
            draw = ImageDraw.Draw(canvas)
            draw.line((40, content_h + 24, page_w - 40, content_h + 24), fill=(210, 210, 210), width=2)
            page = output.new_page(width=page_w, height=page_h)
            page.insert_image(page.rect, stream=self._png_bytes(canvas))
            canvas.close()
        output.save(destination, deflate=True)
        output.close()

    @staticmethod
    def _trim_clip_to_content(page: fitz.Page, clip: fitz.Rect) -> fitz.Rect:
        """Find content bounds from a small preview without retaining page bitmaps."""
        clip = clip & page.rect
        if clip.width <= 0 or clip.height <= 0:
            return fitz.Rect(0, 0, 0, 0)
        probe_scale = min(0.5, 1400 / max(page.rect.width, page.rect.height, 1))
        pix = page.get_pixmap(matrix=fitz.Matrix(probe_scale, probe_scale), clip=clip, alpha=False)
        image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        try:
            gray = image.convert("L")
            try:
                bbox = gray.point(lambda value: 255 if value < 246 else 0).getbbox()
            finally:
                gray.close()
        finally:
            image.close()
        if not bbox:
            return clip
        left, top, right, bottom = bbox
        margin = 10  # PDF points
        trimmed = fitz.Rect(
            pix.x + left / probe_scale - margin,
            pix.y + top / probe_scale - margin,
            pix.x + right / probe_scale + margin,
            pix.y + bottom / probe_scale + margin,
        )
        return trimmed & clip

    @staticmethod
    def _png_bytes(image: Image.Image) -> bytes:
        data = io.BytesIO()
        image.save(data, format="PNG", optimize=True)
        return data.getvalue()


def main() -> None:
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass
    QuestionSlideApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
